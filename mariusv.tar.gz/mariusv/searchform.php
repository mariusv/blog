<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<p class="search-field"><input type="text" value="<?php the_search_query(); ?>" name="s" id="s" /></p>
<!-- <input type="submit" id="searchsubmit" value="Search" /> -->
</form>
