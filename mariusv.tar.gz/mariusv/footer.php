<div id="footnotes" class="col span-12">
	<p>Copyright &copy; 2009&ndash;2010. All rights reserved.</p>
	<p class="rss"><a href="<?php bloginfo('rss2_url'); ?>" title="Syndicate using RSS"><acronym title="Really Simple Syndication">RSS</acronym> Feed</a>. This blog is proudly powered <span class="low">by</span> <a href="http://www.wordpress.org">Wordpress</a>.</p>
</div>
</div>
<?php /* "Just what do you think you're doing Dave?" */ ?>
		<?php wp_footer(); ?>
		
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/blogger.js"></script>
		
		
		<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/abisdemon.json?callback=twitterCallback2&amp;count=1"></script>
</body>
</html>